# 源林舒壓館線上預約網站

這是一套可自行執行的 Flask + SQLite 網站，包含：
- 高級 SPA 風格的繁體中文首頁
- 5 分鐘 NT$150、10 分鐘 NT$200 服務
- 10:00–22:00 營業時段
- 每筆服務後 5 分鐘整理時間
- 每 5 分鐘列出開始時間，檢查重疊預約
- SQLite 儲存預約
- 管理員登入、查看／取消預約、CSV 匯出
- 個人資料使用說明頁

## 重要限制：自動簡訊
本版本沒有串接簡訊供應商，因此**不會真正發送 SMS**。一般網站無法只靠 HTML/Flask 保證免費向台灣手機自動發簡訊；需要支援台灣的簡訊閘道帳號、發送額度與 API 憑證，通常會有費用。請勿將網站顯示的預約成功等同於已發送簡訊。

## 本機執行

需要 Python 3.10 以上。

### Windows
```powershell
py -m venv .venv
.venv\\Scripts\\activate
pip install -r requirements.txt
$env:SECRET_KEY="請換成長且隨機的密碼"
$env:ADMIN_PASSWORD="請設定店家管理密碼"
python app.py
```

### macOS / Linux
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export SECRET_KEY="請換成長且隨機的密碼"
export ADMIN_PASSWORD="請設定店家管理密碼"
python app.py
```

瀏覽器開啟 http://127.0.0.1:5000

管理頁：http://127.0.0.1:5000/admin/login

首次啟動會自動建立 `bookings.db`。

## 正式公開前必做
1. 設定強度足夠且唯一的 `SECRET_KEY` 與 `ADMIN_PASSWORD`。
2. 使用支援 Flask 的主機，並確認 SQLite 資料庫存放在持久化磁碟；免費主機可能休眠、刪除資料或不提供持久磁碟。
3. 使用 HTTPS、定期備份資料庫，並限制管理後台存取。
4. 測試同一時段的併發預約、取消、營業時間、時區與手機版。
5. 若要自動簡訊，選擇支援台灣手機的 SMS gateway，設定 API 憑證與簡訊模板，完成送達測試與費用估算。這項功能不會在未設定供應商時假裝已啟用。
6. 調整個資告知、保存期限與實際營運規則。

## 時段規則
- 5 分鐘服務 + 5 分鐘整理 = 每筆占用 10 分鐘。
- 10 分鐘服務 + 5 分鐘整理 = 每筆占用 15 分鐘。
- 服務需在 22:00 前完成整理。
- 已確認的預約會阻擋重疊時段；取消後釋出時段。
- 管理員可在 `/admin` 查看及取消預約。

## 注意
這是可執行的網站程式，不代表已經部署到公開網域。若只在自己的電腦啟動，只有該電腦上的服務可使用；要讓客人從 Google 地圖開啟，還需部署到可公開存取的主機並設定網域。
