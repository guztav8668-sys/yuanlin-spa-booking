import os
import sqlite3
import csv
import io
from datetime import datetime, date, time, timedelta
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash, session, Response, abort

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.environ.get("DATABASE_PATH", os.path.join(BASE_DIR, "bookings.db"))
app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-before-deployment")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "change-this-password")
SHOP_PHONE = "0928961767"
SHOP_ADDRESS = "台南市新市區富安六街98號"
OPEN_TIME = time(10, 0)
CLOSE_TIME = time(22, 0)
BUFFER_MINUTES = 5
SERVICES = {
    "5": {"name": "舒壓按摩 5 分鐘", "duration": 5, "price": 150},
    "10": {"name": "舒壓按摩 10 分鐘", "duration": 10, "price": 200},
}

def connect_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with connect_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS bookings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                phone TEXT NOT NULL,
                service_key TEXT NOT NULL,
                service_name TEXT NOT NULL,
                price INTEGER NOT NULL,
                duration INTEGER NOT NULL,
                booking_date TEXT NOT NULL,
                start_time TEXT NOT NULL,
                end_minutes INTEGER NOT NULL,
                status TEXT NOT NULL DEFAULT 'confirmed',
                note TEXT DEFAULT '',
                created_at TEXT NOT NULL
            )
        """)
        conn.commit()

def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("admin_logged_in"):
            return redirect(url_for("admin_login", next=request.path))
        return view(*args, **kwargs)
    return wrapped

def parse_start(date_text, time_text):
    try:
        day = date.fromisoformat(date_text)
        hour, minute = map(int, time_text.split(":"))
        start = datetime.combine(day, time(hour, minute))
        return start
    except (ValueError, TypeError):
        return None

def booking_end_minutes(start, duration):
    return start.hour * 60 + start.minute + duration + BUFFER_MINUTES

def is_within_business_hours(start, duration):
    start_minutes = start.hour * 60 + start.minute
    close_minutes = CLOSE_TIME.hour * 60 + CLOSE_TIME.minute
    return start.time() >= OPEN_TIME and start_minutes + duration + BUFFER_MINUTES <= close_minutes

def find_conflict(conn, booking_date, start_minutes, end_minutes):
    # Stored end_minutes includes the 5-minute cleanup buffer.
    row = conn.execute("""
        SELECT id FROM bookings
        WHERE booking_date = ? AND status = 'confirmed'
          AND start_time IS NOT NULL
          AND CAST(substr(start_time,1,2) AS INTEGER) * 60
              + CAST(substr(start_time,4,2) AS INTEGER) < ?
          AND end_minutes > ?
        LIMIT 1
    """, (booking_date, end_minutes, start_minutes)).fetchone()
    return row

@app.route("/", methods=["GET"])
def index():
    today = date.today().isoformat()
    return render_template("index.html", services=SERVICES, today=today,
                           shop_phone=SHOP_PHONE, shop_address=SHOP_ADDRESS)

@app.route("/api/availability", methods=["GET"])
def availability():
    date_text = request.args.get("date", "")
    service_key = request.args.get("service", "")
    if service_key not in SERVICES:
        return {"error": "請先選擇服務項目"}, 400
    try:
        day = date.fromisoformat(date_text)
    except ValueError:
        return {"error": "日期格式不正確"}, 400
    if day < date.today():
        return {"error": "不能預約過去日期"}, 400

    service = SERVICES[service_key]
    duration = service["duration"]
    slots = []
    start = datetime.combine(day, OPEN_TIME)
    close = datetime.combine(day, CLOSE_TIME)
    with connect_db() as conn:
        while start + timedelta(minutes=duration + BUFFER_MINUTES) <= close:
            # Offer 5-minute starts, then reject any interval overlapping an existing booking+buffer.
            end = start + timedelta(minutes=duration + BUFFER_MINUTES)
            available = True
            if day == date.today() and start <= datetime.now():
                available = False
            conflict = find_conflict(conn, day.isoformat(),
                                     start.hour * 60 + start.minute,
                                     end.hour * 60 + end.minute)
            if conflict:
                available = False
            slots.append({
                "time": start.strftime("%H:%M"),
                "available": available,
                "label": start.strftime("%H:%M") + (" · 可預約" if available else " · 已占用")
            })
            start += timedelta(minutes=5)
    return {"slots": slots, "duration": duration, "buffer": BUFFER_MINUTES}

@app.route("/book", methods=["POST"])
def book():
    name = request.form.get("name", "").strip()
    phone = request.form.get("phone", "").strip()
    service_key = request.form.get("service", "")
    date_text = request.form.get("booking_date", "")
    time_text = request.form.get("start_time", "")
    note = request.form.get("note", "").strip()[:500]
    consent = request.form.get("consent") == "yes"

    if not name or len(name) > 80:
        flash("請填寫正確姓名。", "error")
        return redirect(url_for("index"))
    digits = "".join(ch for ch in phone if ch.isdigit())
    if len(digits) < 9 or len(digits) > 15:
        flash("請填寫有效的聯絡電話。", "error")
        return redirect(url_for("index"))
    if service_key not in SERVICES:
        flash("請選擇有效的按摩項目。", "error")
        return redirect(url_for("index"))
    if not consent:
        flash("請先同意預約資料使用告知。", "error")
        return redirect(url_for("index"))

    start = parse_start(date_text, time_text)
    if not start:
        flash("請選擇有效的日期與時間。", "error")
        return redirect(url_for("index"))
    if start < datetime.now() or start.minute % 5 != 0:
        flash("請選擇未來且以 5 分鐘為間隔的時間。", "error")
        return redirect(url_for("index"))

    service = SERVICES[service_key]
    if not is_within_business_hours(start, service["duration"]):
        flash("此時段超出營業時間，請重新選擇。", "error")
        return redirect(url_for("index"))

    start_minutes = start.hour * 60 + start.minute
    end_minutes = booking_end_minutes(start, service["duration"])

    # BEGIN IMMEDIATE makes the conflict check and insert sequential within SQLite.
    conn = connect_db()
    try:
        conn.execute("BEGIN IMMEDIATE")
        conflict = find_conflict(conn, date_text, start_minutes, end_minutes)
        if conflict:
            conn.rollback()
            flash("這個時段剛被預約，請重新選擇其他時間。", "error")
            return redirect(url_for("index"))
        conn.execute("""
            INSERT INTO bookings
            (name, phone, service_key, service_name, price, duration, booking_date,
             start_time, end_minutes, status, note, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'confirmed', ?, ?)
        """, (name, phone, service_key, service["name"], service["price"],
              service["duration"], date_text, time_text, end_minutes, note,
              datetime.now().isoformat(timespec="seconds")))
        conn.commit()
    except sqlite3.Error:
        conn.rollback()
        flash("目前無法完成預約，請稍後再試或直接致電店家。", "error")
        return redirect(url_for("index"))
    finally:
        conn.close()

    # No SMS is sent by this no-paid-service build. Confirmation is shown on the website.
    return render_template("success.html", name=name, service=service,
                           booking_date=date_text, start_time=time_text,
                           shop_phone=SHOP_PHONE, shop_address=SHOP_ADDRESS)

@app.route("/admin", methods=["GET"])
@admin_required
def admin():
    day_filter = request.args.get("date", "")
    with connect_db() as conn:
        if day_filter:
            rows = conn.execute("SELECT * FROM bookings WHERE booking_date=? ORDER BY start_time", (day_filter,)).fetchall()
        else:
            rows = conn.execute("SELECT * FROM bookings ORDER BY booking_date DESC, start_time DESC LIMIT 300").fetchall()
    return render_template("admin.html", bookings=rows, day_filter=day_filter)

@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        password = request.form.get("password", "")
        if password and password == ADMIN_PASSWORD:
            session["admin_logged_in"] = True
            return redirect(request.args.get("next") or url_for("admin"))
        flash("管理密碼不正確。", "error")
    return render_template("login.html")

@app.route("/admin/logout", methods=["POST"])
@admin_required
def admin_logout():
    session.clear()
    return redirect(url_for("index"))

@app.route("/admin/cancel/<int:booking_id>", methods=["POST"])
@admin_required
def cancel_booking(booking_id):
    with connect_db() as conn:
        conn.execute("UPDATE bookings SET status='cancelled' WHERE id=?", (booking_id,))
        conn.commit()
    flash("預約已取消，時段已釋出。此版本不會自動發送簡訊。", "success")
    return redirect(url_for("admin", date=request.form.get("return_date", "")))

@app.route("/admin/export.csv", methods=["GET"])
@admin_required
def export_csv():
    with connect_db() as conn:
        rows = conn.execute("SELECT id,name,phone,service_name,price,booking_date,start_time,status,note,created_at FROM bookings ORDER BY booking_date,start_time").fetchall()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["預約編號","姓名","電話","服務","價格","日期","開始時間","狀態","備註","建立時間"])
    for row in rows:
        writer.writerow(list(row))
    data = "\ufeff" + output.getvalue()
    return Response(data, mimetype="text/csv; charset=utf-8",
                    headers={"Content-Disposition":"attachment; filename=yuanlin_bookings.csv"})

@app.route("/privacy")
def privacy():
    return render_template("privacy.html")

with app.app_context():
    init_db()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", "5000")), debug=False)
